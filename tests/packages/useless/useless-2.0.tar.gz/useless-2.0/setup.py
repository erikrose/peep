from os import environ

from setuptools import setup


# An env var is set by peep's test harness to tell us where to plonk our
# telltale file.
with open(environ['PEEP_TEST_TELLTALE'], 'w') as telltale:
    telltale.write('wrong thing')


setup(
    name='useless',
    version='2.0',
    description='A pretty empty package',
    long_description='Really empty',
    author='Erik Rose',
    author_email='grinch@grinchcentral.com',
    license='MIT',
    py_modules=['useless'],
    include_package_data=True
)
