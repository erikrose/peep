from setuptools import setup


setup(
    name='useless',
    version='1.0',
    description='A pretty empty package',
    long_description='Really empty',
    author='Erik Rose',
    author_email='grinch@grinchcentral.com',
    license='MIT',
    py_modules=['useless'],
    include_package_data=True
)
